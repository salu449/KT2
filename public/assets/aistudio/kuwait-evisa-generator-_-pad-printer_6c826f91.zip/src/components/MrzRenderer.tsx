import React from 'react';

interface MrzLineProps {
  line: string;
  chevronScaleY?: number;
  letterSpacing?: string;
  strokeWidth?: number; // 0 = natural clean stroke (default)
  fontWeight?: string | number; // 'normal' | 400
  className?: string;
}

export const MrzLine: React.FC<MrzLineProps> = ({
  line,
  chevronScaleY = 1.0,
  letterSpacing = '0.11em',
  strokeWidth = 0.07,
  fontWeight = 'normal',
  className = '',
}) => {
  const effectiveStroke = typeof strokeWidth === 'number' ? strokeWidth : 0.07;
  const hasStroke = effectiveStroke > 0;
  const outerStrokeStyle: React.CSSProperties = hasStroke
    ? {
        WebkitTextStroke: `${effectiveStroke}px #000000`,
        paintOrder: 'stroke fill',
      }
    : {
        WebkitTextStroke: '0px',
        textShadow: 'none',
      };

  const parsedWeight =
    fontWeight === 'bold' || fontWeight === 700 || fontWeight === '700'
      ? 700
      : 400;

  return (
    <div
      style={{
        fontFamily: '"Orator Std", "OratorStd", "Share Tech Mono", monospace',
        fontWeight: parsedWeight,
        fontSynthesis: 'none',
        letterSpacing,
        color: '#000000',
        ...outerStrokeStyle,
      }}
      className={`inline-flex items-center select-all uppercase text-black whitespace-nowrap leading-none tracking-[0.11em] font-orator-mrz mrz-stroke ${className}`}
    >
      {chevronScaleY === 1.0 ? (
        // When chevronScaleY is 1.0 (default), render line directly as text for pixel-perfect typography matching official Kuwait eVisa exactly
        <span className="font-orator-mrz select-all tracking-[0.11em] leading-none">
          {line}
        </span>
      ) : (
        // When chevronScaleY is customized by user, scale the filler chevrons
        line.split('').map((char, index) => {
          if (char === '<') {
            return (
              <span
                key={index}
                className="inline-flex items-center justify-center font-orator-mrz select-all"
                style={{
                  width: '1ch',
                  height: '1em',
                  lineHeight: 1,
                  transform: `scaleY(${chevronScaleY})`,
                  transformOrigin: 'center center',
                }}
                title="MRZ Filler"
              >
                &lt;
              </span>
            );
          }
          return (
            <span
              key={index}
              className="inline-block text-center font-orator-mrz select-all"
              style={{
                width: '1ch',
                height: '1em',
                lineHeight: 1,
              }}
            >
              {char}
            </span>
          );
        })
      )}
    </div>
  );
};
