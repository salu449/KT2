import React, { useState } from 'react';
import {
  Type,
  RotateCcw,
  Eye,
  EyeOff,
  Sparkles,
  Search,
  Check,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import {
  PadCalibration,
  AVAILABLE_FONTS,
  LINE_DEFINITIONS,
  LineKey,
  LineFontConfig,
  getLineStyle,
  savePadSettings,
} from '../services/padService';

interface LineFontManagerProps {
  calibration: PadCalibration;
  onCalibrationChange: (cal: PadCalibration) => void;
  onSavePermanently?: () => void;
  defaultDocFont?: string;
}

export const LineFontManager: React.FC<LineFontManagerProps> = ({
  calibration,
  onCalibrationChange,
  onSavePermanently,
  defaultDocFont = 'Myanmar Text',
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [expandedKey, setExpandedKey] = useState<LineKey | null>(null);

  const lineStyles = calibration.lineStyles || {};
  const nameLineSpacing = calibration.nameLineSpacing || 0;

  const handleUpdateNameSpacing = (newVal: number) => {
    const clamped = Math.max(-25, Math.min(50, newVal));
    const nextCal = {
      ...calibration,
      nameLineSpacing: clamped,
    };
    onCalibrationChange(nextCal);
    savePadSettings({ calibration: nextCal });
    if (onSavePermanently) onSavePermanently();
  };

  const handleUpdateMrzStroke = (newVal: number) => {
    const clamped = Math.max(0, Math.min(0.25, Number(newVal.toFixed(2))));
    const nextCal = {
      ...calibration,
      mrzStrokeWidth: clamped,
    };
    onCalibrationChange(nextCal);
    savePadSettings({ calibration: nextCal });
    if (onSavePermanently) onSavePermanently();
  };

  const handleUpdateLine = (key: LineKey, updates: Partial<LineFontConfig>) => {
    const current = lineStyles[key] || {};
    const updatedLineStyles = {
      ...lineStyles,
      [key]: {
        ...current,
        ...updates,
      },
    };
    const nextCal = {
      ...calibration,
      lineStyles: updatedLineStyles,
    };
    onCalibrationChange(nextCal);
    savePadSettings({ calibration: nextCal });
    if (onSavePermanently) onSavePermanently();
  };

  const handleResetLine = (key: LineKey) => {
    const nextStyles = { ...lineStyles };
    delete nextStyles[key];
    const nextCal = {
      ...calibration,
      lineStyles: nextStyles,
    };
    onCalibrationChange(nextCal);
    savePadSettings({ calibration: nextCal });
    if (onSavePermanently) onSavePermanently();
  };

  const handleResetAllLines = () => {
    const ok = window.confirm('আপনি কি সব লাইনের ফন্ট সেটিংস ডিফল্ট মানে রিসেট করতে চান?');
    if (!ok) return;
    const nextCal = {
      ...calibration,
      lineStyles: {},
    };
    onCalibrationChange(nextCal);
    savePadSettings({ calibration: nextCal });
    if (onSavePermanently) onSavePermanently();
  };

  const filteredLines = LINE_DEFINITIONS.filter((item) => {
    const matchesSearch =
      item.labelBn.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.labelEn.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.key.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const categories = [
    { id: 'all', label: 'সকল লাইন' },
    { id: 'primary', label: 'নম্বর ও তারিখ' },
    { id: 'passport', label: 'পাসপোর্ট ফিল্ড' },
    { id: 'name', label: 'নাম ও পরিচয়' },
    { id: 'details', label: 'অন্যান্য তথ্য' },
    { id: 'mrz', label: 'MRZ কোড' },
  ];

  return (
    <div className="space-y-4">
      {/* Informative Header Banner */}
      <div className="bg-gradient-to-r from-sky-50 via-indigo-50 to-purple-50 border border-sky-200 p-3 rounded-2xl flex items-start gap-2.5">
        <div className="w-8 h-8 rounded-xl bg-sky-600 text-white flex items-center justify-center shrink-0 shadow-xs">
          <Type className="w-4 h-4" />
        </div>
        <div className="text-xs text-sky-950 flex-1">
          <div className="flex items-center gap-1.5 font-bold text-sky-900">
            <span>লাইনভিত্তিক ফন্ট ও প্রিন্ট কাস্টমাইজার</span>
            <span className="bg-sky-200/80 text-sky-800 text-[10px] px-1.5 py-0.2 rounded-full font-mono">
              Individual Font Control
            </span>
          </div>
          <p className="text-[11px] text-sky-800/80 mt-0.5 leading-relaxed">
            এখানে প্রতিটা লাইনের জন্য আলাদাভাবে <strong>ফন্ট ফ্যামিলি (Font Family)</strong>,{' '}
            <strong>ফন্ট সাইজ (Size)</strong>, <strong>বোল্ডনেস (Bold/Normal)</strong> ও{' '}
            <strong>প্রিন্ট দৃশ্যমানতা (Print Toggle)</strong> পরিবর্তন করতে পারবেন।
          </p>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row gap-2 items-center justify-between">
        <div className="relative w-full sm:w-64">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="লাইন বা ফিল্ড খুঁজুন..."
            className="w-full pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 focus:bg-white focus:border-sky-500 rounded-xl text-xs outline-none"
          />
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
          {categories.map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => setSelectedCategory(c.id)}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all cursor-pointer whitespace-nowrap ${
                selectedCategory === c.id
                  ? 'bg-sky-600 text-white shadow-2xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {c.label}
            </button>
          ))}
        </div>
      </div>

      {/* Action Header */}
      <div className="flex items-center justify-between text-xs border-b border-slate-200 pb-2">
        <span className="text-slate-500 font-medium">
          মোট {filteredLines.length} টি লাইনের ফন্ট নিয়ন্ত্রণ
        </span>
        <div className="flex items-center gap-2">
          {Object.keys(lineStyles).length > 0 && (
            <button
              type="button"
              onClick={handleResetAllLines}
              className="text-[11px] text-rose-600 hover:text-rose-700 font-semibold flex items-center gap-1 cursor-pointer"
            >
              <RotateCcw className="w-3 h-3" />
              <span>সব ফন্ট ডিফল্ট করুন</span>
            </button>
          )}
        </div>
      </div>

      {/* Name Line Spacing Quick Tool if viewing 'all' or 'name' */}
      {(selectedCategory === 'all' || selectedCategory === 'name') && !searchQuery && (
        <div className="bg-gradient-to-r from-sky-50 via-indigo-50 to-blue-50 border border-sky-200/90 rounded-xl p-3 shadow-2xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-indigo-600 animate-pulse" />
              <span>আরবি ও ইংরেজি নামের মাঝের স্পেস (Line Spacing)</span>
            </span>
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] font-mono font-bold text-indigo-800 bg-white px-2 py-0.5 rounded border border-indigo-200">
                {nameLineSpacing > 0 ? `+${nameLineSpacing}` : nameLineSpacing} px
              </span>
              {nameLineSpacing !== 0 && (
                <button
                  type="button"
                  onClick={() => handleUpdateNameSpacing(0)}
                  className="text-[10px] text-slate-500 hover:text-rose-600 underline cursor-pointer"
                >
                  রিসেট
                </button>
              )}
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => handleUpdateNameSpacing(nameLineSpacing - 1)}
              className="w-7 h-7 rounded-lg bg-white border border-slate-300 hover:bg-slate-100 flex items-center justify-center font-bold text-slate-700 text-xs shadow-2xs cursor-pointer select-none active:scale-95"
              title="১ পিক্সেল কমান"
            >
              -
            </button>
            <input
              type="range"
              min={-20}
              max={40}
              step={1}
              value={nameLineSpacing}
              onChange={(e) => handleUpdateNameSpacing(parseInt(e.target.value, 10))}
              className="flex-1 accent-indigo-600 h-1.5 cursor-pointer"
            />
            <button
              type="button"
              onClick={() => handleUpdateNameSpacing(nameLineSpacing + 1)}
              className="w-7 h-7 rounded-lg bg-white border border-slate-300 hover:bg-slate-100 flex items-center justify-center font-bold text-slate-700 text-xs shadow-2xs cursor-pointer select-none active:scale-95"
              title="১ পিক্সেল বাড়ান"
            >
              +
            </button>
          </div>
          <div className="flex flex-wrap items-center gap-1 pt-1 border-t border-indigo-100/70 text-[10px]">
            <span className="text-slate-500 font-medium">প্রিসেট:</span>
            {[
              { label: 'টাইট (-4px)', val: -4 },
              { label: 'ডিফল্ট (0px)', val: 0 },
              { label: 'সামান্য (+3px)', val: 3 },
              { label: 'মিডিয়াম (+6px)', val: 6 },
              { label: 'বেশি (+10px)', val: 10 },
              { label: 'প্রশস্ত (+16px)', val: 16 },
            ].map((p) => (
              <button
                key={p.val}
                type="button"
                onClick={() => handleUpdateNameSpacing(p.val)}
                className={`px-1.5 py-0.5 rounded border transition-colors cursor-pointer ${
                  nameLineSpacing === p.val
                    ? 'bg-indigo-600 text-white border-indigo-600'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* MRZ Stroke & Natural Weight Tool if viewing 'all' or 'mrz' */}
      {(selectedCategory === 'all' || selectedCategory === 'mrz') && !searchQuery && (
        <div className="bg-gradient-to-r from-emerald-50 via-teal-50 to-slate-50 border border-emerald-200/90 rounded-xl p-3 shadow-2xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-600 animate-pulse" />
              <span>MRZ ফন্ট ঘনত্ব ও স্ট্রোক (Optical Weight & Stroke)</span>
            </span>
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] font-mono font-bold text-emerald-800 bg-white px-2 py-0.5 rounded border border-emerald-200">
                {(calibration.mrzStrokeWidth ?? 0.07) === 0.07
                  ? '🎯 ব্যালান্সড (0.07px)'
                  : (calibration.mrzStrokeWidth ?? 0.07) === 0
                  ? 'খুব হালকা (0px)'
                  : `+${calibration.mrzStrokeWidth}px`}
              </span>
              {(calibration.mrzStrokeWidth ?? 0.07) !== 0.07 && (
                <button
                  type="button"
                  onClick={() => handleUpdateMrzStroke(0.07)}
                  className="text-[10px] text-emerald-700 hover:text-emerald-900 underline font-semibold cursor-pointer"
                >
                  ব্যালান্সড করুন (0.07)
                </button>
              )}
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => handleUpdateMrzStroke(Math.max(0, Number(((calibration.mrzStrokeWidth ?? 0.07) - 0.01).toFixed(2))))}
              className="w-7 h-7 rounded-lg bg-white border border-slate-300 hover:bg-slate-100 flex items-center justify-center font-bold text-slate-700 text-xs shadow-2xs cursor-pointer select-none active:scale-95"
              title="স্ট্রোক কমান (হালকা করুন)"
            >
              -
            </button>
            <input
              type="range"
              min={0}
              max={0.2}
              step={0.01}
              value={calibration.mrzStrokeWidth ?? 0.07}
              onChange={(e) => handleUpdateMrzStroke(parseFloat(e.target.value))}
              className="flex-1 accent-emerald-600 h-1.5 cursor-pointer"
            />
            <button
              type="button"
              onClick={() => handleUpdateMrzStroke(Math.min(0.2, Number(((calibration.mrzStrokeWidth ?? 0.07) + 0.01).toFixed(2))))}
              className="w-7 h-7 rounded-lg bg-white border border-slate-300 hover:bg-slate-100 flex items-center justify-center font-bold text-slate-700 text-xs shadow-2xs cursor-pointer select-none active:scale-95"
              title="স্ট্রোক বাড়ান (গাঢ় করুন)"
            >
              +
            </button>
          </div>
          <div className="flex flex-wrap items-center gap-1 pt-1 border-t border-emerald-100/70 text-[10px]">
            <span className="text-slate-500 font-medium">প্রিসেট:</span>
            {[
              { label: 'খুব হালকা (0px)', val: 0 },
              { label: '🎯 পারফেক্ট ব্যালান্স (0.07px - রেফারেন্স অনুযায়ী)', val: 0.07 },
              { label: 'সামান্য গাঢ় (+0.12px)', val: 0.12 },
              { label: 'গাঢ় (+0.18px)', val: 0.18 },
            ].map((p) => (
              <button
                key={p.val}
                type="button"
                onClick={() => handleUpdateMrzStroke(p.val)}
                className={`px-1.5 py-0.5 rounded border transition-colors cursor-pointer ${
                  (calibration.mrzStrokeWidth ?? 0.07) === p.val
                    ? 'bg-emerald-600 text-white border-emerald-600 font-bold shadow-2xs'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Line Items List */}
      <div className="space-y-2.5 max-h-[52vh] overflow-y-auto pr-1">
        {filteredLines.map((def) => {
          const custom = lineStyles[def.key] || {};
          const isCustomized = Object.keys(custom).length > 0;
          const currentFont = custom.fontFamily || (def.arabicField ? 'Cairo' : def.defaultFontFamily || defaultDocFont);
          const currentSize = custom.fontSize !== undefined ? custom.fontSize : def.defaultFontSize + (calibration.fontSizeOffset || 0);
          const currentWeight = custom.fontWeight || def.defaultFontWeight;
          const currentSpacing = custom.letterSpacing || (def.category === 'mrz' ? '0.08em' : 'normal');
          const isVisible = custom.visible !== false;
          const isExpanded = expandedKey === def.key;

          const previewStyle = getLineStyle(def.key, calibration, defaultDocFont);

          return (
            <div
              key={def.key}
              className={`bg-white rounded-xl border transition-all shadow-2xs ${
                isCustomized
                  ? 'border-sky-300 ring-1 ring-sky-100'
                  : 'border-slate-200 hover:border-slate-300'
              }`}
            >
              {/* Card Header / Summary Row */}
              <div className="p-3 flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5 min-w-0">
                  <button
                    type="button"
                    onClick={() => handleUpdateLine(def.key, { visible: !isVisible })}
                    className={`p-1.5 rounded-lg transition-colors cursor-pointer shrink-0 ${
                      isVisible
                        ? 'text-sky-600 hover:bg-sky-50'
                        : 'text-slate-400 bg-slate-100 hover:bg-slate-200'
                    }`}
                    title={isVisible ? 'প্রিন্টে এই লাইনটি প্রিন্ট হবে (ক্লিক করলে হাইড হবে)' : 'এই লাইনটি প্রিন্ট হবে না (ক্লিক করলে শো হবে)'}
                  >
                    {isVisible ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4 text-amber-600" />}
                  </button>

                  <div className="truncate">
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-bold text-slate-900 truncate">
                        {def.labelBn}
                      </span>
                      {isCustomized && (
                        <span className="text-[9px] bg-sky-100 text-sky-800 font-bold px-1.5 py-0.2 rounded font-mono shrink-0">
                          কাস্টম
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2 text-[10px] text-slate-500 mt-0.5">
                      <span className="font-semibold text-slate-700">{currentFont}</span>
                      <span>•</span>
                      <span className="font-mono font-bold text-sky-700">{currentSize}px</span>
                      <span>•</span>
                      <span>{currentWeight === 'bold' ? 'বোল্ড' : currentWeight === 'normal' ? 'নরমাল' : 'এক্সট্রা বোল্ড'}</span>
                    </div>
                  </div>
                </div>

                {/* Right Quick Controls */}
                <div className="flex items-center gap-1.5 shrink-0">
                  {/* Quick Font Size Stepper */}
                  <div className="flex items-center bg-slate-100 rounded-lg p-0.5 border border-slate-200">
                    <button
                      type="button"
                      onClick={() => handleUpdateLine(def.key, { fontSize: Math.max(8, Number((currentSize - 0.5).toFixed(1))) })}
                      className="w-6 h-6 rounded bg-white hover:bg-slate-200 active:bg-slate-300 font-bold text-slate-800 flex items-center justify-center text-xs cursor-pointer shadow-2xs select-none"
                      title="ফন্ট সাইজ ০.৫ কমান"
                    >
                      -
                    </button>
                    <span className="text-[11px] font-mono font-bold text-slate-800 min-w-[36px] text-center px-1">
                      {currentSize}
                    </span>
                    <button
                      type="button"
                      onClick={() => handleUpdateLine(def.key, { fontSize: Math.min(36, Number((currentSize + 0.5).toFixed(1))) })}
                      className="w-6 h-6 rounded bg-white hover:bg-slate-200 active:bg-slate-300 font-bold text-slate-800 flex items-center justify-center text-xs cursor-pointer shadow-2xs select-none"
                      title="ফন্ট সাইজ ০.৫ বাড়ান"
                    >
                      +
                    </button>
                  </div>

                  {/* Expand / Customize Details */}
                  <button
                    type="button"
                    onClick={() => setExpandedKey(isExpanded ? null : def.key)}
                    className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                      isExpanded
                        ? 'bg-sky-50 border-sky-300 text-sky-700'
                        : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                    title="বিস্তারিত ফন্ট সেটিংস খুলুন"
                  >
                    {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Live Mini Preview Bar */}
              <div className="px-3 pb-2 pt-0.5 flex items-center justify-between border-t border-slate-100 bg-slate-50/50 rounded-b-xl">
                <span className="text-[10px] text-slate-400">লাইভ ভিউ:</span>
                <span
                  style={previewStyle}
                  className="truncate max-w-[340px] text-slate-900 select-all"
                >
                  {def.key === 'visaNumber'
                    ? '354210309'
                    : def.key === 'referenceNumber'
                    ? '376554492'
                    : def.key === 'nameArabic'
                    ? 'محمد عبد الغفار محمد'
                    : def.key === 'nameEnglish'
                    ? 'MD ABDUL GAFFAR'
                    : def.key === 'mrzLine1'
                    ? 'ISLAM<<MD<ABDUL<GAFFAR<<<<<<<<<<<<<<<<<<'
                    : def.key === 'mrzLine2'
                    ? '3527690440BGD8910200M2609153372711511<<<<<<<'
                    : 'Sample Value 2026-09-15'}
                </span>
                {isCustomized && (
                  <button
                    type="button"
                    onClick={() => handleResetLine(def.key)}
                    className="text-[10px] text-slate-400 hover:text-rose-600 underline cursor-pointer ml-2 shrink-0"
                    title="এই লাইনের ফন্ট ডিফল্টে ফেরান"
                  >
                    রিসেট
                  </button>
                )}
              </div>

              {/* Expanded Detailed Settings Panel */}
              {isExpanded && (
                <div className="p-3 bg-slate-50 border-t border-slate-200 space-y-3 rounded-b-xl">
                  {/* Font Family Selector */}
                  <div>
                    <label className="text-[11px] font-bold text-slate-700 block mb-1">
                      ফন্ট ফ্যামিলি (Font Family):
                    </label>
                    <select
                      value={currentFont}
                      onChange={(e) => handleUpdateLine(def.key, { fontFamily: e.target.value })}
                      className="w-full bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs font-semibold text-slate-900 focus:ring-1 focus:ring-sky-500 outline-none"
                    >
                      {AVAILABLE_FONTS.map((font) => (
                        <option key={font.id} value={font.id}>
                          {font.label}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Font Size & Weight Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {/* Size Slider */}
                    <div>
                      <div className="flex items-center justify-between text-[11px] mb-1">
                        <span className="font-bold text-slate-700">ফন্ট সাইজ (px):</span>
                        <span className="font-mono font-bold text-sky-700 bg-sky-50 px-1.5 py-0.2 rounded border border-sky-200">
                          {currentSize} px
                        </span>
                      </div>
                      <input
                        type="range"
                        min={8}
                        max={34}
                        step={0.5}
                        value={currentSize}
                        onChange={(e) => handleUpdateLine(def.key, { fontSize: parseFloat(e.target.value) })}
                        className="w-full accent-sky-600 h-1.5 cursor-pointer"
                      />
                    </div>

                    {/* Font Weight */}
                    <div>
                      <span className="text-[11px] font-bold text-slate-700 block mb-1">
                        বোল্ডনেস (Weight):
                      </span>
                      <div className="grid grid-cols-3 gap-1">
                        {[
                          { id: 'normal', label: 'নরমাল' },
                          { id: 'bold', label: 'বোল্ড' },
                          { id: 'extrabold', label: 'মোটা' },
                        ].map((w) => (
                          <button
                            key={w.id}
                            type="button"
                            onClick={() => handleUpdateLine(def.key, { fontWeight: w.id })}
                            className={`py-1 text-[11px] font-semibold rounded-md border transition-all cursor-pointer ${
                              currentWeight === w.id
                                ? 'bg-sky-600 text-white border-sky-600 shadow-2xs'
                                : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                            }`}
                          >
                            {w.label}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Letter Spacing & Color */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                    <div>
                      <span className="text-[11px] font-bold text-slate-700 block mb-1">
                        অক্ষরের ফাঁক (Letter Spacing):
                      </span>
                      <div className="flex items-center gap-1">
                        {[
                          { id: 'normal', label: 'ডিফল্ট' },
                          { id: '0.04em', label: 'মিডিয়াম' },
                          { id: '0.08em', label: 'প্রশস্ত' },
                          { id: '0.12em', label: 'বেশি' },
                        ].map((sp) => (
                          <button
                            key={sp.id}
                            type="button"
                            onClick={() => handleUpdateLine(def.key, { letterSpacing: sp.id })}
                            className={`flex-1 py-1 text-[10px] font-semibold rounded-md border transition-all cursor-pointer ${
                              currentSpacing === sp.id
                                ? 'bg-sky-600 text-white border-sky-600'
                                : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                            }`}
                          >
                            {sp.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-4 sm:pt-2">
                      <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-slate-700">
                        <input
                          type="checkbox"
                          checked={isVisible}
                          onChange={(e) => handleUpdateLine(def.key, { visible: e.target.checked })}
                          className="rounded text-sky-600 focus:ring-sky-500"
                        />
                        <span>প্রিন্টে এই লাইনটি প্রদর্শন করুন</span>
                      </label>
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Bottom Save Reminder */}
      {onSavePermanently && (
        <div className="pt-2 flex justify-end">
          <button
            type="button"
            onClick={onSavePermanently}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-md cursor-pointer transition-colors"
          >
            <Check className="w-4 h-4" />
            <span>সকল ফন্ট সেটিংস স্থায়ীভাবে সেভ করুন</span>
          </button>
        </div>
      )}
    </div>
  );
};
